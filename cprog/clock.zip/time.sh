#!/bin/bash 

date -s "16:45"

python3 natprov_ntp.py


date 
