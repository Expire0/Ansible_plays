#!/bin/bash 

date -s "16:45"

python3 demo.py


date 
